import React from 'react';
import { FolderPlus, BookOpen, Play, FileCode, PlusSquare, Home } from 'lucide-react';
import { NavLink } from 'react-router-dom';
import { Tab } from '../types';

interface SidebarProps {
  activeTab: string;
}

const tabs: Tab[] = [
  { id: '/', label: 'Home', icon: 'Home' },
  { id: '/nos-apis', label: 'NOS APIs', icon: 'FileCode' },
  { id: '/getting-started', label: 'Getting Started', icon: 'Play' },
  { id: '/documentation', label: 'Documentation', icon: 'BookOpen' },
  { id: '/create-folder', label: 'Create Folder', icon: 'FolderPlus' },
  { id: '/generate-spring', label: 'Generate Spring Project', icon: 'PlusSquare' },
];

const iconComponents = {
  Home,
  FileCode,
  Play,
  BookOpen,
  FolderPlus,
  PlusSquare,
};

export default function Sidebar({ activeTab }: SidebarProps) {
  return (
    <div className="w-64 bg-gray-900 h-screen fixed left-0 top-0 text-white p-4">
      <div className="flex items-center gap-2 mb-8">
        <FileCode className="w-8 h-8 text-blue-400" />
        <h1 className="text-xl font-bold">SGABS Docs</h1>
      </div>
      
      <nav>
        {tabs.map((tab) => {
          const Icon = iconComponents[tab.icon as keyof typeof iconComponents];
          return (
            <NavLink
              key={tab.id}
              to={tab.id}
              className={({ isActive }) =>
                `w-full flex items-center gap-3 px-4 py-3 rounded-lg mb-2 transition-colors ${
                  isActive
                    ? 'bg-blue-600 text-white'
                    : 'text-gray-300 hover:bg-gray-800'
                }`
              }
            >
              <Icon className="w-5 h-5" />
              <span>{tab.label}</span>
            </NavLink>
          );
        })}
      </nav>
    </div>
  );
}