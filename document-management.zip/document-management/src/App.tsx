import React from 'react';
import { Routes, Route, useLocation } from 'react-router-dom';
import Sidebar from './components/Sidebar';
import Header from './components/Header';
import Home from './pages/Home';
import NOSApis from './pages/NOSApis';
import Documentation from './pages/Documentation';
import GettingStarted from './pages/GettingStarted';
import CreateFolder from './pages/CreateFolder';
import GenerateSpring from './pages/GenerateSpring';

function App() {
  const location = useLocation();
  const activeTab = location.pathname;

  return (
    <div className="min-h-screen bg-gray-50">
      <Sidebar activeTab={activeTab} />
      <div className="ml-64">
        <Header />
        <main className="pt-16 min-h-screen">
          <div className="max-w-7xl mx-auto">
            <Routes>
              <Route path="/" element={<Home />} />
              <Route path="/nos-apis" element={<NOSApis />} />
              <Route path="/getting-started" element={<GettingStarted />} />
              <Route path="/documentation" element={<Documentation />} />
              <Route path="/create-folder" element={<CreateFolder />} />
              <Route path="/generate-spring" element={<GenerateSpring />} />
            </Routes>
          </div>
        </main>
      </div>
    </div>
  );
}

export default App;