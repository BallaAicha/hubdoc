import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Book, Code2, FolderPlus } from 'lucide-react';

interface QuickAccessCardProps {
  title: string;
  description: string;
  icon: React.ReactNode;
  path: string;
}

function QuickAccessCard({ title, description, icon, path }: QuickAccessCardProps) {
  const navigate = useNavigate();
  
  return (
    <button
      onClick={() => navigate(path)}
      className="bg-white p-6 rounded-xl shadow-sm hover:shadow-md transition-shadow border border-gray-200 text-left"
    >
      <div className="w-12 h-12 bg-blue-50 rounded-lg flex items-center justify-center mb-4">
        <div className="text-blue-600">{icon}</div>
      </div>
      <h3 className="text-lg font-semibold text-gray-900 mb-2">{title}</h3>
      <p className="text-gray-600">{description}</p>
    </button>
  );
}

export default function Home() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 p-6">
      <QuickAccessCard
        title="Documentation"
        description="Access all documentation, FAQs, and development standards"
        icon={<Book className="w-6 h-6" />}
        path="/documentation"
      />
      <QuickAccessCard
        title="NOS APIs"
        description="Explore and integrate with our API collection"
        icon={<Code2 className="w-6 h-6" />}
        path="/nos-apis"
      />
      <QuickAccessCard
        title="Create New"
        description="Create folders, documents, or generate Spring projects"
        icon={<FolderPlus className="w-6 h-6" />}
        path="/create-folder"
      />
    </div>
  );
}