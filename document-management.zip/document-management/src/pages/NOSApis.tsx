import React from 'react';
import { Code2, GitBranch, Lock, Share2 } from 'lucide-react';

const apis = [
  {
    name: 'User Management API',
    description: 'RESTful API for managing user accounts, roles, and permissions',
    version: 'v2.1.0',
    status: 'Stable',
    endpoints: [
      { method: 'GET', path: '/api/v2/users', description: 'List all users' },
      { method: 'POST', path: '/api/v2/users', description: 'Create new user' },
      { method: 'PUT', path: '/api/v2/users/:id', description: 'Update user' }
    ]
  },
  {
    name: 'Authentication API',
    description: 'Secure authentication and authorization endpoints',
    version: 'v1.3.2',
    status: 'Stable',
    endpoints: [
      { method: 'POST', path: '/api/v1/auth/login', description: 'User login' },
      { method: 'POST', path: '/api/v1/auth/refresh', description: 'Refresh token' }
    ]
  },
  {
    name: 'Document Service API',
    description: 'API for document management and version control',
    version: 'v1.0.0',
    status: 'Beta',
    endpoints: [
      { method: 'GET', path: '/api/v1/documents', description: 'List all documents' },
      { method: 'POST', path: '/api/v1/documents', description: 'Create document' }
    ]
  }
];

export default function NOSApis() {
  return (
    <div className="p-6">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">NOS APIs</h1>
        <p className="text-gray-600">Explore and integrate with our collection of internal APIs</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {apis.map((api) => (
          <div key={api.name} className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
            <div className="p-6">
              <div className="flex items-start justify-between">
                <div>
                  <h2 className="text-xl font-semibold text-gray-900 mb-2">{api.name}</h2>
                  <p className="text-gray-600 mb-4">{api.description}</p>
                </div>
                <Code2 className="w-6 h-6 text-blue-500" />
              </div>

              <div className="flex gap-4 mb-6">
                <span className="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-blue-50 text-blue-700">
                  {api.version}
                </span>
                <span className="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-green-50 text-green-700">
                  {api.status}
                </span>
              </div>

              <div className="space-y-3">
                {api.endpoints.map((endpoint) => (
                  <div key={endpoint.path} className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg">
                    <span className="px-2 py-1 bg-blue-100 text-blue-700 rounded text-sm font-mono">
                      {endpoint.method}
                    </span>
                    <code className="text-sm text-gray-700">{endpoint.path}</code>
                  </div>
                ))}
              </div>
            </div>

            <div className="border-t border-gray-200 bg-gray-50 p-4">
              <div className="flex gap-4">
                <button className="btn-secondary flex items-center gap-2">
                  <GitBranch className="w-4 h-4" />
                  <span>View Docs</span>
                </button>
                <button className="btn-secondary flex items-center gap-2">
                  <Lock className="w-4 h-4" />
                  <span>Auth</span>
                </button>
                <button className="btn-secondary flex items-center gap-2">
                  <Share2 className="w-4 h-4" />
                  <span>Share</span>
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}