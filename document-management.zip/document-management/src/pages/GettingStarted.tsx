import React from 'react';
import { Terminal, Package, GitBranch, Database, Server, Shield } from 'lucide-react';

const steps = [
  {
    title: 'Install Development Tools',
    icon: <Terminal className="w-6 h-6" />,
    description: 'Set up your local development environment with required tools',
    tasks: [
      { text: 'Install Node.js (v18+)', completed: false },
      { text: 'Install Java JDK 17', completed: false },
      { text: 'Install Docker Desktop', completed: false },
      { text: 'Install Git', completed: false }
    ]
  },
  {
    title: 'Configure Dependencies',
    icon: <Package className="w-6 h-6" />,
    description: 'Set up project dependencies and development tools',
    tasks: [
      { text: 'Configure Maven settings', completed: false },
      { text: 'Set up npm registry', completed: false },
      { text: 'Install global dev tools', completed: false }
    ]
  },
  {
    title: 'Clone Repositories',
    icon: <GitBranch className="w-6 h-6" />,
    description: 'Get access to and clone necessary repositories',
    tasks: [
      { text: 'Generate SSH key', completed: false },
      { text: 'Add key to GitLab', completed: false },
      { text: 'Clone main project', completed: false }
    ]
  },
  {
    title: 'Database Setup',
    icon: <Database className="w-6 h-6" />,
    description: 'Configure local database environment',
    tasks: [
      { text: 'Install PostgreSQL', completed: false },
      { text: 'Create local database', completed: false },
      { text: 'Run migrations', completed: false }
    ]
  },
  {
    title: 'Configure Services',
    icon: <Server className="w-6 h-6" />,
    description: 'Set up local services and environment variables',
    tasks: [
      { text: 'Configure .env file', completed: false },
      { text: 'Start required services', completed: false },
      { text: 'Verify connections', completed: false }
    ]
  },
  {
    title: 'Security Setup',
    icon: <Shield className="w-6 h-6" />,
    description: 'Configure security credentials and access',
    tasks: [
      { text: 'Generate API keys', completed: false },
      { text: 'Configure VPN access', completed: false },
      { text: 'Set up 2FA', completed: false }
    ]
  }
];

export default function GettingStarted() {
  return (
    <div className="p-6">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Getting Started</h1>
        <p className="text-gray-600">Follow these steps to set up your development environment</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {steps.map((step) => (
          <div key={step.title} className="bg-white rounded-xl shadow-sm border border-gray-200">
            <div className="p-6">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-12 h-12 bg-blue-50 rounded-lg flex items-center justify-center">
                  <div className="text-blue-600">{step.icon}</div>
                </div>
                <div>
                  <h2 className="text-xl font-semibold text-gray-900">{step.title}</h2>
                  <p className="text-gray-600 text-sm">{step.description}</p>
                </div>
              </div>

              <div className="space-y-3">
                {step.tasks.map((task, index) => (
                  <div
                    key={index}
                    className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg"
                  >
                    <input
                      type="checkbox"
                      checked={task.completed}
                      onChange={() => {}}
                      className="h-5 w-5 rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                    />
                    <span className="text-gray-700">{task.text}</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="border-t border-gray-200 p-4">
              <button className="w-full btn-primary">Mark Section Complete</button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}