import React, { useState } from 'react';
import { PlusSquare, Package, Cpu, Database, Shield } from 'lucide-react';

const dependencies = [
  { id: 'web', name: 'Spring Web', description: 'Build web applications using Spring MVC', icon: Package },
  { id: 'data-jpa', name: 'Spring Data JPA', description: 'Persist data in SQL stores with Java Persistence API', icon: Database },
  { id: 'security', name: 'Spring Security', description: 'Highly customizable authentication and access-control', icon: Shield },
  { id: 'actuator', name: 'Spring Actuator', description: 'Monitor and manage your application', icon: Cpu }
];

export default function GenerateSpring() {
  const [projectName, setProjectName] = useState('');
  const [groupId, setGroupId] = useState('com.sgabs');
  const [artifactId, setArtifactId] = useState('');
  const [description, setDescription] = useState('');
  const [selectedDeps, setSelectedDeps] = useState<string[]>([]);

  const toggleDependency = (depId: string) => {
    setSelectedDeps(prev =>
      prev.includes(depId)
        ? prev.filter(id => id !== depId)
        : [...prev, depId]
    );
  };

  return (
    <div className="p-6">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Generate Spring Project</h1>
        <p className="text-gray-600">Create a new Spring Boot project with predefined standards</p>
      </div>

      <div className="max-w-4xl bg-white rounded-xl shadow-sm border border-gray-200">
        <div className="p-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Project Name
              </label>
              <input
                type="text"
                value={projectName}
                onChange={(e) => setProjectName(e.target.value)}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                placeholder="My Spring Project"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Group ID
              </label>
              <input
                type="text"
                value={groupId}
                onChange={(e) => setGroupId(e.target.value)}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                placeholder="com.example"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Artifact ID
              </label>
              <input
                type="text"
                value={artifactId}
                onChange={(e) => setArtifactId(e.target.value)}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                placeholder="my-spring-project"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Description
              </label>
              <input
                type="text"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                placeholder="Project description"
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-4">
              Dependencies
            </label>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {dependencies.map((dep) => {
                const Icon = dep.icon;
                return (
                  <button
                    key={dep.id}
                    onClick={() => toggleDependency(dep.id)}
                    className={`flex items-start gap-4 p-4 rounded-lg border ${
                      selectedDeps.includes(dep.id)
                        ? 'border-blue-500 bg-blue-50'
                        : 'border-gray-200 hover:bg-gray-50'
                    }`}
                  >
                    <Icon className="w-6 h-6 text-blue-600 mt-1" />
                    <div className="text-left">
                      <h3 className="font-medium text-gray-900">{dep.name}</h3>
                      <p className="text-sm text-gray-600">{dep.description}</p>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>
        </div>

        <div className="border-t border-gray-200 p-4">
          <button className="w-full btn-primary flex items-center justify-center gap-2">
            <PlusSquare className="w-5 h-5" />
            <span>Generate Project</span>
          </button>
        </div>
      </div>
    </div>
  );
}