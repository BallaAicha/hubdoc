import React, { useState } from 'react';
import { FolderPlus, Image, File, X } from 'lucide-react';

export default function CreateFolder() {
  const [folderName, setFolderName] = useState('');
  const [description, setDescription] = useState('');
  const [selectedType, setSelectedType] = useState('documentation');
  const [tags, setTags] = useState<string[]>([]);
  const [currentTag, setCurrentTag] = useState('');

  const handleAddTag = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && currentTag.trim()) {
      setTags([...tags, currentTag.trim()]);
      setCurrentTag('');
    }
  };

  const removeTag = (tagToRemove: string) => {
    setTags(tags.filter(tag => tag !== tagToRemove));
  };

  return (
    <div className="p-6">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Create New Folder</h1>
        <p className="text-gray-600">Create a new folder or document in the repository</p>
      </div>

      <div className="max-w-2xl bg-white rounded-xl shadow-sm border border-gray-200">
        <div className="p-6">
          <div className="mb-6">
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Folder Name
            </label>
            <input
              type="text"
              value={folderName}
              onChange={(e) => setFolderName(e.target.value)}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              placeholder="Enter folder name"
            />
          </div>

          <div className="mb-6">
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Description
            </label>
            <textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              rows={4}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              placeholder="Enter folder description"
            />
          </div>

          <div className="mb-6">
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Type
            </label>
            <div className="grid grid-cols-2 gap-4">
              <button
                onClick={() => setSelectedType('documentation')}
                className={`flex items-center gap-3 p-4 rounded-lg border ${
                  selectedType === 'documentation'
                    ? 'border-blue-500 bg-blue-50'
                    : 'border-gray-200 hover:bg-gray-50'
                }`}
              >
                <File className="w-5 h-5 text-blue-600" />
                <span className="font-medium">Documentation</span>
              </button>
              <button
                onClick={() => setSelectedType('media')}
                className={`flex items-center gap-3 p-4 rounded-lg border ${
                  selectedType === 'media'
                    ? 'border-blue-500 bg-blue-50'
                    : 'border-gray-200 hover:bg-gray-50'
                }`}
              >
                <Image className="w-5 h-5 text-blue-600" />
                <span className="font-medium">Media</span>
              </button>
            </div>
          </div>

          <div className="mb-6">
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Tags
            </label>
            <div className="flex flex-wrap gap-2 mb-3">
              {tags.map((tag) => (
                <span
                  key={tag}
                  className="inline-flex items-center gap-1 px-3 py-1 bg-gray-100 rounded-full text-sm"
                >
                  {tag}
                  <button
                    onClick={() => removeTag(tag)}
                    className="w-4 h-4 flex items-center justify-center rounded-full hover:bg-gray-200"
                  >
                    <X className="w-3 h-3" />
                  </button>
                </span>
              ))}
            </div>
            <input
              type="text"
              value={currentTag}
              onChange={(e) => setCurrentTag(e.target.value)}
              onKeyDown={handleAddTag}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              placeholder="Add tags (press Enter)"
            />
          </div>
        </div>

        <div className="border-t border-gray-200 p-4">
          <button className="w-full btn-primary flex items-center justify-center gap-2">
            <FolderPlus className="w-5 h-5" />
            <span>Create Folder</span>
          </button>
        </div>
      </div>
    </div>
  );
}