import React from 'react';
import { Book, FileText, Users, Workflow } from 'lucide-react';

const categories = [
  {
    title: 'Getting Started',
    icon: <Book className="w-6 h-6" />,
    documents: [
      { title: 'Development Environment Setup', views: 1234 },
      { title: 'Code Style Guidelines', views: 890 },
      { title: 'Project Structure', views: 567 }
    ]
  },
  {
    title: 'Best Practices',
    icon: <Workflow className="w-6 h-6" />,
    documents: [
      { title: 'API Design Guidelines', views: 2341 },
      { title: 'Security Best Practices', views: 1567 },
      { title: 'Performance Optimization', views: 890 }
    ]
  },
  {
    title: 'Team Guidelines',
    icon: <Users className="w-6 h-6" />,
    documents: [
      { title: 'Code Review Process', views: 678 },
      { title: 'Git Workflow', views: 1234 },
      { title: 'Release Process', views: 456 }
    ]
  }
];

export default function Documentation() {
  return (
    <div className="p-6">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Documentation</h1>
        <p className="text-gray-600">Access all documentation, FAQs, and development standards</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {categories.map((category) => (
          <div key={category.title} className="bg-white rounded-xl shadow-sm border border-gray-200">
            <div className="p-6">
              <div className="flex items-center gap-3 mb-6">
                <div className="w-12 h-12 bg-blue-50 rounded-lg flex items-center justify-center">
                  <div className="text-blue-600">{category.icon}</div>
                </div>
                <h2 className="text-xl font-semibold text-gray-900">{category.title}</h2>
              </div>

              <div className="space-y-4">
                {category.documents.map((doc) => (
                  <div
                    key={doc.title}
                    className="flex items-center justify-between p-4 hover:bg-gray-50 rounded-lg cursor-pointer transition-colors"
                  >
                    <div className="flex items-center gap-3">
                      <FileText className="w-5 h-5 text-gray-400" />
                      <span className="text-gray-700">{doc.title}</span>
                    </div>
                    <span className="text-sm text-gray-500">{doc.views} views</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="border-t border-gray-200 p-4">
              <button className="w-full btn-secondary">View All</button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}