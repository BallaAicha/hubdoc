export type Tab = {
  id: string;
  label: string;
  icon: string;
};

export type Document = {
  id: string;
  title: string;
  content: string;
  version: number;
  createdAt: string;
  updatedAt: string;
  access: 'private' | 'public' | 'restricted';
};